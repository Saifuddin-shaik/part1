import java.sql.PreparedStatement;

public class Connection {

	public PreparedStatement prepareStatement(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void commit() {
		// TODO Auto-generated method stub
		
	}

}
