

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class jdbc
 */
@WebServlet("/jdbc")
public class jdbc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public jdbc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			PrintWriter out=response.getWriter();
		
        
		Online ab=new Online();
		String Username = request.getParameter("Username");
		String Email = request.getParameter("Email");
		String Password = request.getParameter("Password");
		String Confirm_password = request.getParameter("Confirm_password");
		out.println(Username);
        out.println(Email);
        out.println(Password);
        out.println(Confirm_password);
        ab.setUsername(Username);
		ab.setEmail(Email);
		ab.setPassword(Password);
		ab.setConfirm_password(Confirm_password);
		Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded successfully");
        java.sql.Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
        System.out.println("connection is established");
        PreparedStatement ps=con.prepareStatement("insert into SignupForm values(?,?,?,?)");
        ps.setString(1, ab.getUsername());
        ps.setString(2, ab.getEmail());
        ps.setString(3, ab.getPassword());
        ps.setString(4, ab.getConfirm_password());
        int k = ps.executeUpdate();
        if(k>0){
            System.out.println("welcome");
            response.sendRedirect("NewFile.html");
            con.commit();           
        }
        
        }
        catch(SQLException|ClassNotFoundException e){
            System.out.println(e);
       
        }
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
