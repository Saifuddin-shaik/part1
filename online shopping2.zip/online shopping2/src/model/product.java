package model;

public class product {
int pid,pprice,pquantity;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public int getPprice() {
	return pprice;
}
public void setPprice(int pprice) {
	this.pprice = pprice;
}
public int getPquantity() {
	return pquantity;
}
public void setPquantity(int pquantity) {
	this.pquantity = pquantity;
}
public category getPcategory() {
	return pcategory;
}
public void setPcategory(category pcategory) {
	this.pcategory = pcategory;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
category pcategory;
String pname;
}
