 
import java.io.IOException;

 import java.io.PrintWriter;

 import java.sql.DriverManager;

 import java.sql.PreparedStatement;

 import java.sql.SQLException;
 
import javax.servlet.ServletException;

 import javax.servlet.annotation.WebServlet;

 import javax.servlet.http.HttpServlet;

 import javax.servlet.http.HttpServletRequest;

 import javax.servlet.http.HttpServletResponse;
 
/**

  * Servlet implementation class jdbc

  */

 @WebServlet("/jdbc")

 public class jdbc2 extends HttpServlet {

     private static final long serialVersionUID = 1L;


     /**

      * @see HttpServlet#HttpServlet()

      */

     public jdbc2() {

         super();

         // TODO Auto-generated constructor stub

     }
 
    /**

      * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

      */

     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


         try{

             PrintWriter out=response.getWriter();

         String Username = request.getParameter("Username");        

         String Password = request.getParameter("Password");

         out.println(Username);

         out.println(Password);

         Online2 abc=new Online2();

         abc.setUsername(Username);        

         abc.setPassword(Password);    

         Class.forName("oracle.jdbc.driver.OracleDriver");

         System.out.println("Driver loaded successfully");

         java.sql.Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");

         System.out.println("connection is established");

         PreparedStatement ps=con.prepareStatement("insert into Login values(?,?)");

         ps.setString(1, abc.getUsername());        

         ps.setString(2, abc.getPassword());


         int h = ps.executeUpdate();

         if(h>0){

             System.out.println("welcome");

             response.sendRedirect("NewFile2.html");

             con.commit();           

         }

         }

         catch(SQLException|ClassNotFoundException e){

             System.out.println(e);


         }



     }
 
    /**

      * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

      */

     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

         // TODO Auto-generated method stub

         doGet(request, response);

     }
 
}