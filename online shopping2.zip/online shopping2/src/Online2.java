public class Online2 {
 
        String Username;

         String Password;

         public Online2(String Username, String Password) {

             super();

             this.Username = Username;

             this.Password = Password;


         }

         public Online2() {

             // TODO Auto-generated constructor stub

         }                

         public String getUsername() {

             return Username;

         }

         public void setUsername(String username) {

             this.Username = username;

         }



         public String getPassword() {

             return Password;

         }

         public void setPassword(String password) {

             this.Password = password;

         }


     }