package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.category;
import model.product;

public class ProductDao {
public int insert(product p) throws ClassNotFoundException, SQLException{
	

		 Class.forName("oracle.jdbc.driver.OracleDriver");

		 System.out.println("Driver Loaded");

		 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");

		 System.out.println("Connection Established");

		 PreparedStatement ps=con.prepareStatement( "insert into product values(T.nextval,?,?,?,?)");
		 ps.setString(1,p.getPname());
		 ps.setInt(2,p.getPprice());
		 ps.setInt(3,p.getPquantity());
		 ps.setInt(4,p.getPcategory().getCid());
		return ps.executeUpdate();
	
}
   public List<product> getall() throws ClassNotFoundException, SQLException{
	  List <product>reference=new ArrayList<product>();
	  Class.forName("oracle.jdbc.driver.OracleDriver");

		 System.out.println("Driver Loaded");

		 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");

		 System.out.println("Connection Established");

		 PreparedStatement ps=con.prepareStatement( "select * from product");
		 ResultSet rs=ps.executeQuery();
		 while(rs.next())
		 {
			 product d=new product();
			 category ge=new category();
			 d.setPid(rs.getInt("pid"));
			 d.setPname(rs.getString("pname"));
			 d.setPprice(rs.getInt("pprice"));
			 d.setPquantity(rs.getInt("pquantity"));
			 ge.setCid(rs.getInt("pcategory"));
			 d.setPcategory(ge);
			 reference.add(d);
			 
			 }
	return reference;
	
   }
   
}

